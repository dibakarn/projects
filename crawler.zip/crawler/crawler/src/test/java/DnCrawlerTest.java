import static org.junit.Assert.*;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.junit.Test;

import com.dn.crawler.DnCrawler;

public class DnCrawlerTest {

	@Test
	public void test1()  throws Exception{
		  
		  DnCrawler dnCrawler=new DnCrawler();
		  String url="https://wiprodigital.com";
		  String domain="https://wiprodigital.com";
		  String fileName="output.xml";
		  String sampleFileName="D:/Sample/sample.xml";
		  dnCrawler.MAX_LAVEL=0;
		  dnCrawler.startCrawler(url,domain,fileName);
		  String sampleOutput=getFileContent(sampleFileName);
		  String actualOutput=getFileContent(fileName);
		  boolean thrown = false;

		  if(sampleOutput.equals(actualOutput))
			  thrown = true;
		  
		  
		  assertTrue(thrown);
	}

	public static String getFileContent(String sampleFileName) throws IOException {
		File file = new File(sampleFileName); 
		  
		  BufferedReader br = new BufferedReader(new FileReader(file)); 
		  StringBuilder  sb=new StringBuilder ();
		  String st; 
		  while ((st = br.readLine()) != null) {
			  sb.append(st);
		  } 
		
		  return sb.toString();
	}
}
