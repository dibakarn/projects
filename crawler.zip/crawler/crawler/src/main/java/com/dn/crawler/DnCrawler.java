package com.dn.crawler;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
/**
* This code will visit all pages in the domain
*
* @author  Dibakar Nandi
* @version 1.0
* @since   2018-11-03 
*/
public class DnCrawler {
	public int MAX_LAVEL=3;   
	public static void main(String[] args) throws Exception {
		  DnCrawler dnCrawler=new DnCrawler();
		  String url=null;
		  String domain=null;
		  String fileName=null;
		  
		  if(args.length<4) {
			  System.out.println("Please enter valid argument java -jar crawler-0.0.1-SNAPSHOT.jar <URL> <DOMAIN> <FILANAME> <LAVEL>");
		  }
		  else {
			  url=args[0];
			  domain=args[1];
			  fileName=args[2];
			  
			  dnCrawler.MAX_LAVEL=Integer.valueOf(args[3]);
			  dnCrawler.startCrawler(url,domain,fileName);
		  }
	}
	
	 /**
	   * This method will visit given page and all sub page.
	   * 
	   * 
	   * @param url This is page url
	   * @param domain  This is page domain
	   * @param fileName  This is the outputFileName;
	   */
	public void startCrawler(String url,String domain,String outputFileName) throws Exception {
		  
	       ArrayList<String> isAllreadyVisited=new ArrayList<String>();
	       isAllreadyVisited.add(domain);
	       ArrayList<String> urlList=visitPage(url,domain,isAllreadyVisited,0);
	     
	       String str = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
  		    		"\t<sitemap>\r\n";
	        for(String urls:urlList) {
	        	if(urls.endsWith(".png") || urls.endsWith(".gif") || urls.endsWith(".jpg")) {
	        		str+="\t\t<image>\r\n\t\t\t<loc>"+urls+"</loc>\r\n\t\t</image>\r\n";
	        	}
	        	else if(urls.endsWith(".js")) {
	        		str+="\t\t<script>\r\n\t\t\t<loc>"+urls+"</loc>\r\n\t\t</script>\r\n";
	        	}
	        	else if(urls.endsWith(".css")) {
	        		str+="\t\t<css>\r\n\t\t\t<loc>"+urls+"</loc>\r\n\t\t</css>\r\n";
	        	}else {
	        		str+="\t\t<url>\r\n\t\t\t<loc>"+urls+"</loc>\r\n\t\t</url>\r\n";
	        	}
	        }

  		    str += 	"\t</sitemap>" ;
	        writeFile(str,outputFileName);
	   }
	   
	   /**
	   * This method will visit given page and all sub page.
	   * 
	   * 
	   * @param urlLink This is page url
	   * @param domain  This is page domain
	   * @param isAllreadyVisited  This is the isAllreadyVisited list
	   * @param lavel  This is the lavel of sub pages
	   * @return ArrayList<String> This returns all url inside the url;
	   */
	   public  ArrayList<String> visitPage(String urlLink,String domain,ArrayList<String> isAllreadyVisited,int lavel)  {
		   ArrayList<String> urlList=new ArrayList<String>();
		   isAllreadyVisited.add(urlLink);
		   try {
	        URL url = new URL(urlLink);
	        BufferedReader in = new BufferedReader(
	        new InputStreamReader(url.openStream()));
	        StringBuilder sb=new StringBuilder();
	        String inputLine;
	        while ((inputLine = in.readLine()) != null)
	        	sb.append(inputLine);
	        in.close();
	       
	     
	        
	        //System.out.println(sb);
	        ArrayList<String> linkUrlList =traverseTag(sb.toString(),"<link ",">","href");
	        for(String urls:linkUrlList) {
	        	if(!urlList.contains(urls)) {
	        		urlList.add(urls);
	        	}
	        }
	        
	        linkUrlList =traverseTag(sb.toString(),"<script ",">","src");
	      
	        for(String urls:linkUrlList) {
	        	if(!urlList.contains(urls)) {
	        		urlList.add(urls);
	        	}
	        }
	        
	        linkUrlList =traverseTag(sb.toString(),"<meta property=\"og:image\" ",">","content");
	        for(String urls:linkUrlList) {
	        	if(!urlList.contains(urls)) {
	        		urlList.add(urls);
	        	}
	        }
	        
	        linkUrlList =traverseTag(sb.toString(),"<a ",">","href");
	        for(String urls:linkUrlList) {
	        	if(!urlList.contains(urls)) {
	        		urlList.add(urls);
	        	}
	        }
	        
	        if(lavel<MAX_LAVEL) {
		        for(String urls:linkUrlList) {
		        	ArrayList<String> subUrlList=null;
		        	if(!isAllreadyVisited.contains(urls) && !isAllreadyVisited.contains(domain+"/"+urls)) {
			        	if(urls.startsWith("http") && urls.startsWith(domain)) {
			        		System.out.println(urls);
			        		
			        		subUrlList=visitPage(urls,domain,isAllreadyVisited,lavel+1);
			        		for(String urls1:subUrlList) {
			     	        	if(!urlList.contains(urls1)) {
			     	        		urlList.add(urls1);
			     	        	}
			     	        }
			        	}else if(!urls.startsWith("http") ){
			        		System.out.println(urls);
			        		
			        		subUrlList=visitPage(domain+"/"+urls,domain,isAllreadyVisited,lavel+1);
			        		for(String urls1:subUrlList) {
			     	        	if(!urlList.contains(urls1)) {
			     	        		urlList.add(urls1);
			     	        	}
			     	        }
			        	}
		        	}
		        }
	        }
		   }
		   catch(Exception e) {
			   
		   }
	        
	        return urlList;
	        
	 }
	 
	   
	   /**
	   * This method will visit given page and find given tag and URL
	   * 
	   * 
	   * @param sbs This is page content
	   * @param tagStart  This is start of tag
	   * @param tagEnd  This is the end of tag
	   * @param urlElement  This is the url element where will find the tag
	   * @return ArrayList<String> This returns all url inside the tag;
	   */  
	 public  ArrayList<String> traverseTag(String sbs,String tagStart,String tagEnd,String urlElement) {
		 ArrayList<String> urlList=new ArrayList<String>();
	        int spos=0;
	        String tagUrl="";
	        while(spos!=-1) {
	        	tagUrl=findTagUrl(sbs,spos,tagStart,tagEnd,urlElement);
	        	
	        	if(!tagUrl.equals("")) {
	        		if(!tagUrl.startsWith("#") && !tagUrl.startsWith("mailto:"))
	        			urlList.add(tagUrl);
	        		spos=sbs.indexOf(tagEnd,spos+1);
	        	}else {
	        		break;
	        	}
	        }
	        return urlList;
	 }
	 
	 /**
	   * This method will find tag and url
	   * 
	   * 
	   * @param content This is page content
	   * @param pos  This is position in the content
	   * @param tagStart  This is start of tag
	   * @param tagEnd  This is the end of tag
	   * @param urlElement  This is the url element where will find the tag
	   * @return String This returns  url inside the tag;
	   */  
	 public  String findTagUrl(String content,int pos,String tagStart,String endTag,String urlElement) {
		 int spos=content.indexOf(tagStart,pos);
		 if(spos!=-1) {
			 return findUrl(content.substring(spos,content.indexOf(endTag,spos+tagStart.length())+1),urlElement);
		 }else {
			 return "";
		 }
	 }
	 
	 /**
	   * This method will find url from url content
	   * 
	   * 
	   * @param tagContent This is tag content
	   * @param urlElement  This is url element where will find the url
	   * @return String This returns  url inside the tag;
	   */  
	 public  String findUrl(String tagContent,String urlElement) {
		 int spos=tagContent.indexOf(urlElement);
		 if(spos!=-1) {
			if(tagContent.indexOf("\"",spos+1)!=-1 && (tagContent.indexOf("'",spos+1)==-1 || tagContent.indexOf("\"",spos+1)<tagContent.indexOf("'",spos+1)))
				return tagContent.substring(tagContent.indexOf("\"",spos+1)+1,tagContent.indexOf("\"",tagContent.indexOf("\"",spos+1)+1));
			else if(tagContent.indexOf("'",spos+1)!=-1)
				return tagContent.substring(tagContent.indexOf("'",spos+1)+1,tagContent.indexOf("'",tagContent.indexOf("'",spos+1)+1));
			else
				return "";
		 }else {
			 return "";
		 }
			 
	 }
	 
	 /**
	   * This method will write content in file
	   * 
	   * 
	   * @param content This is the content
	   * @param fileName  This is the fileName
	   * 
	   */  
	 public  void writeFile(String content,String fileName) throws Exception {
		 try {
   		   
   		    BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
   		    writer.write(content);
   		     
   		    writer.close();
   		}catch( Exception e) {
   			throw new Exception("Error "+e.getMessage());
   		}
	 }
}
