                          Dn Crawler

 Assumption
 -----------------------
 Currently finding the URL from below tags only,
 1.LINK
 2.SCRIPT
 3.META property=\"og:image\"
 4.A
 
 Considering below extensions as image
 1.png
 2.gif
 3.jpg
 
 Unit testing is doing base on SAMPLE output with level 1
 Don’t handle error for each and every argument
 Considering the website have valid URL in the tag. All tags have a valid end tag.
 Need to test in other domain currently tested only in  https://wiprodigital.com 
 
 
 Build
	To build you need maven in your system run the maven from eclipse or command line

 Run the command using below command
	java -jar crawler-0.0.1-SNAPSHOT.jar <URL> <DOMAIN> <FILANAME> <LAVEL>
 
 Example:
	java -jar crawler-0.0.1-SNAPSHOT.jar https://wiprodigital.com https://wiprodigital.com output.xml
